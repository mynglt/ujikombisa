async function updateData() {
  try {
    const res = await fetch('/data');
    const data = await res.json();

    document.getElementById("temp").textContent = data.temperature;
    document.getElementById("hum").textContent = data.humidity;
    document.getElementById("moist").textContent = data.moisture;

    updateRelayButton("relay1Btn", data.relay1);
    updateRelayButton("relay2Btn", data.relay2);
    updateMoistureGauge(Number(data.moisture));
  } catch (err) {
    console.error("Gagal ambil data:", err);
  }
}

async function toggleRelay(num) {
  try {
    const res = await fetch('/relay?num=' + num, { method: 'POST' });
    const data = await res.json();
    console.log(`Relay ${num} status: ${data.status}`);
    updateRelayButton("relay" + num + "Btn", data.status);
  } catch (err) {
    console.error(`Gagal toggle relay ${num}:`, err);
  }
}

function updateRelayButton(id, state) {
  const btn = document.getElementById(id);
  btn.classList.remove("on", "off");
  btn.classList.add(state ? "on" : "off");
}

function updateMoistureGauge(value) {
  if (moistureChart) {
    moistureChart.data.datasets[0].data = [value, 100 - value];
    moistureChart.update();
  }
}

function createMoistureGauge(initialValue) {
  const ctx = document.getElementById("moistureGauge").getContext("2d");

  moistureChart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Moisture", "Remaining"],
      datasets: [{
        data: [initialValue, 100 - initialValue],
        backgroundColor: ["#00cc44", "#e0e0e0"],
        borderWidth: 1,
      }]
    },
    options: {
      cutout: "70%",
      responsive: false,
      plugins: {
        tooltip: { enabled: false },
        legend: { display: false },
      }
    },
    plugins: [{
      id: 'textCenter',
      beforeDraw(chart) {
        const { ctx, chartArea: { width, height } } = chart;
        ctx.save();
        ctx.font = 'bold 24px Arial';
        ctx.fillStyle = '#333';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const value = chart.data.datasets[0].data[0];
        ctx.clearRect(width / 2 - 30, height / 2 - 20, 60, 40);
        ctx.fillText(`${value}%`, width / 2, height / 2);
        ctx.restore();
      }
    }]
  });
}


window.onload = () => {
  createMoistureGauge(0);
  updateData();
  setInterval(updateData, 3000);

  document.getElementById("relay1Btn").addEventListener("click", () => toggleRelay(1));
  document.getElementById("relay2Btn").addEventListener("click", () => toggleRelay(2));
};
